(() => {
  const c = (s) => (s || '').replace(/\s+/g, ' ').trim()
  const all = [...document.querySelectorAll('tbody tr')].filter((t) => t.querySelectorAll('td').length >= 7)
  const head = all.find((t) => [...t.querySelectorAll('td')].some((td) => c(td.innerText) === '抖音号'))
  const heads = head ? [...head.querySelectorAll('td')].map((td) => c(td.innerText)) : []
  const col = (name, dflt) => { const i = heads.findIndex((h) => h === name); return i >= 0 ? i : dflt }
  const iAweme = col('抖音号', 1), iStatus = col('投放状态', 2), iTool = col('调控工具', 4)
  const isData = (t) => t !== head && !/^共\d+条计划/.test(c(t.innerText))
  const dataRows = all.filter(isData)
  const groupsOf = (td) => [...(td ? td.querySelectorAll('[class*="assistTask"],[class*="assist-task"]') : [])]
  const labelOf = (g) => c((g.querySelector('[class*="taskLabel"],.title') || g).innerText).slice(0, 20)
  const DISABLED = /icon-not-allowed|actionIconDisabled/
  const want = '{{AWEME}}'
  const hits = dataRows.filter((t) => { const td = t.querySelectorAll('td'); return td[iAweme] && c(td[iAweme].innerText).includes(want) })
  if (!hits.length) return JSON.stringify({ err: 'NO_ROW' })
  if (hits.length > 1) return JSON.stringify({ err: 'MULTI_ROW', n: hits.length })
  const tds = hits[0].querySelectorAll('td')
  const status = c(tds[iStatus].innerText)
  const groups = groupsOf(tds[iTool])
  const g0 = groups.find((g) => labelOf(g).startsWith('一键调速')) || groups[0]
  const plus = g0 ? g0.querySelector('iconpark-icon[name="oc-icon-plus"]') : null
  const box = g0 ? g0.getBoundingClientRect() : null
  return JSON.stringify({
    ok: true,
    nick: c(tds[iAweme].innerText).slice(0, 20),
    status,
    live: /投放中/.test(status) && !/未开播/.test(status),
    hasPlus: !!plus,
    plusDisabled: !!(plus && DISABLED.test(plus.className || '')),
    hasPause: !!tds[iTool].querySelector('iconpark-icon[name="iconPauseFilled"]'),
    group: box ? { x: Math.round(box.x), y: Math.round(box.y), w: Math.round(box.width), h: Math.round(box.height) } : null,
    groups: groups.map(labelOf),
  })
})()
